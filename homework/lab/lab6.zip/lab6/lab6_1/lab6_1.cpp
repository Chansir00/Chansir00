#include <iostream>
#include <string>

using namespace std;

class Controller
{
private:
    double m_P;
    double m_I;
    double m_D;
    string m_type = "PID";

public:
    Controller(double P, double I, double D) :m_P(P), m_I(I), m_D(D) {}
    string type(double P, double I, double D);
};

string Controller::type(double P, double I, double D)
{
    if (P == 0)
        return "error";
    if (D == 0)
        m_type.pop_back();
    if (I == 0)
        m_type.pop_back();
    return m_type;
}


int main()
{
    double P, I, D;
    cout << "请分别输入PID" << endl;
    cin >> P >> I >> D;
    Controller c(P, I, D);
    cout << c.type(P, I, D) << endl;
    return 0;
}