#ifndef MYHEAD
#define MYHEAD

#include<iostream>
using namespace std;

static int n = 0;  //int n 重定义？
class Complex
{
private:
    double m_real = 0;
    double m_imag = 0;
public:
    Complex(double real = 0, double imag = 0);   //构造函数
    Complex(const Complex& rhs);      //拷贝构造
    double real();
    double imag();
    void set(double real, double imag);
    friend ostream& operator<<(ostream& os, const Complex& rhs);
    Complex& operator+(const Complex& rhs);
    Complex& operator-(const Complex& rhs);
    Complex& operator*(const Complex& rhs);
    Complex& operator/(const Complex& rhs);
    Complex& operator=(const Complex& rhs);
    friend bool operator==(const Complex& left, const Complex& right);    //涉及到访问两个对象的函数，需要做友元
    friend bool operator!=(const Complex& left, const Complex& right);  //const成员函数可以被const对象和非const对象调用；非const成员函数只能被非const对象调用，不能被const对象调用
    int number();
    ~Complex();
};

#endif